/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 *
 * @author AVALOS
 */

    
    
public class ClassConection {
    public Connection conecion(){
        Connection cn = null;
        try{
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
         cn=DriverManager.getConnection("jdbc:sqlserver://mtymc-PC:1433;DatabaseNametienda;","sa","123");
         }catch(  ClassNotFoundException | SQLException c){}
       return cn; 
    }

   
}
